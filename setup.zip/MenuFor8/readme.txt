﻿Menu For 8について

**はじめに**
ご利用ありがとうございます。
利用の前に以下のセットアップが必要です。
1. Setup.exeよりインストールする。
2. Window 8のスタートメニューからMenuFor8を右クリックし、「タスクバーにピン止めする」をクリック。
3. タスクバー右端へアイコンを移動させる。
以上です。

**このソフトについて**
このソフトはConsumer Preview以降のWindow 8にスタートボタンが存在せず、スタートメニューを復活させる手段がないことから開発されたソフトです。
Windows 8を対象として開発されています。Windows 8以外では利用できない可能性があります。

**カスタマイズについて**
右クリックのプロパティでは最低限の設定しかできません。詳細な設定はStartMenuSetting.xmlを編集して行ってください。
StartMenuSetting.xmlのXml SchemaファイルはStartMenuSetting.xsdです。

**利用に関する注意**
1. このソフトはWindows 8の標準的なスタートメニューへの移行のための暫定的な利用として推奨します。
   Windos 8において旧来のスタートメニューは廃止されました。これはMicrosoftのMetro推進の意向を示唆するものです。
   このような代替手段の利用はMicrosoftが想定した利用法とは異なると考えられます。
   今後Microsoftはスタートメニューのサポートを減らしていくと思われます。(ショートカットで構成されたProgramsフォルダの削除やユーザーへの補助廃止等)
   将来的に問題が発生しないよう代替ソフトへの依存は推奨できません。
2. このソフトは修正BSDライセンスで配布されています。ただし、以下のファイルはMicrosoft社の著作物であり別のライセンスが適用されます。
   1. Microsoft.WindowsAPICodePack.dll
   2. Microsoft.WindowsAPICodePack.Shell.dll
   またこれらのファイルを含むことによりライセンスが制限される可能性があります。その場合、Microsoftによるライセンスが優先され適用されます。
   別途、これらのファイルを含まないソースコードを配布いたします。そちらをご利用ください。
   詳しくはLisence.txtを参照してください。
3. このソフトはメンテナンスを終了しました。問題が発生しても修正されない可能性があります。
   また寄付など頂いても期待にそえないものとお考えください。
   改良や問題修正などは自ら修正・コンパイルして行ってください。
4. このソフトは自分の学習を目的として作成されたものです。

**xsdフォルダについて**
このフォルダにはstartMenuSetting.xmlのXML SchemaやKnownFolders(既知のフォルダ)に関する情報が入っています。
このフォルダ内のライセンスも上の通りです。このフォルダ内にも上のMicrosoft.WindowsAPICodePack.dllとMicrosoft.WindowsAPICodePack.Shell.dllが入っています。
このフォルダの内容はインストールされません。

**連絡**
以下のメールアドレスにどうぞ。
kurema_makoto_software@yahoo.co.jp

**アンインストール**
通常通り「プログラムのアンインストール」等の項目から削除できます。

---------------------------------------------
商標等について。
Microsoft は米国 Microsoft Corporation の米国およびその他の国における登録商標または商標です。
Windows、Windows Server、Windows Vista、Windows 7 は米国 Microsoft Corporation の米国およびその他の国における登録商標または商標です。
Visual Studio、Visual Basic、Visual C#、Visual C++ は米国 Microsoft Corporation の米国およびその他の国における登録商標または商標です。
.NET Framework は米国 Microsoft Corporation の米国およびその他の国における登録商標または商標です。
Windowsの正式名称は、Microsoft Windows Operating Systemです。
Windows 8は現時点での開発コードネームです。将来名称が変更される可能性があります。
その他、本ソフトウェアに記載の製品名は、各社の商標または登録商標です。